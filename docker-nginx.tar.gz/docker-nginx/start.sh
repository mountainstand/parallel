#!/bin/bash

workdir=$(cd $(dirname $0); pwd)
docker build -t nginx:alpine $workdir
docker run -d --name vcvc -p 80:80 nginx:alpine
